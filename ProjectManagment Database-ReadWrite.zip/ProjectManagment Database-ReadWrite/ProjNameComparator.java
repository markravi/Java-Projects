// Assignment #:8
//         Name:Markanday Ravi
//    StudentID:1209205799	
//      Lecture:T/Th 10:30
//  Description: The class compares the location then name of two project objects, returns the value
import java.util.Comparator;

public class ProjNameComparator implements Comparator<Project> {
	public int compare(Project first, Project second){
		int returnValue = first.getLocation().compareTo(second.getLocation());
		
		
		
		
		if(returnValue == 0){
			returnValue=first.getName().compareTo(second.getName());
			
		
		}
	
			
		return returnValue;
	}
}
