// Assignment #:8
//         Name:Markanday Ravi
//    StudentID:1209205799	
//      Lecture:T/Th 10:30
//  Description: The class compares the project number of two project objects, returns the value
import java.util.Comparator;
public class ProjNumberComparator implements Comparator<Project>{

	public int compare(Project first, Project second){
		
		int i = 0;
		if(first.getNumber()< second.getNumber()){
			return i = -1;
		}else if(first.getNumber() > second.getNumber())
			return i = 1;
	
	    else{
		return i;
	}
	
	}
		}
