// Assignment #:8
//         Name:Markanday Ravi
//    StudentID:1209205799	
//      Lecture:T/Th 10:30
//  Description: The class sorts the arraylist using selection sort
import java.util.ArrayList;
import java.util.Comparator;

public class Sorts {
	public static void sort(ArrayList objects, Comparator<Project> proj) {
		//Initialize basic variables
		Project first, second, temp;
		
		int min;

		for(int index = 0; index < objects.size()-1;index++){
			min = index;
			
			for(int scan = index+1; scan<objects.size();scan++){
				first = (Project)objects.get(min);
				second = (Project)objects.get(scan);
				
				if(proj.compare(first, second) > 0){
					min = scan;//sets min to scan only 
							//if the first object is greater than the second one that is being compared
				}
				
				
				
			
				
			}
			temp = (Project)objects.get(min);
			objects.set(min,(Project)objects.get(index));
			objects.set(index,temp);
			//switches the placement of the objects within the arryalist
		}
	}
}
