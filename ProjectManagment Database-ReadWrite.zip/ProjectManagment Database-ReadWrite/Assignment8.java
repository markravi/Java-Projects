// Assignment #: 8
//         Name:Markanday Ravi
//    StudentID:1209205799
//      Lecture:T/TH 10:30
//  Description: The Assignment 8 class displays a menu of choices to a user
//               and performs the chosen task. It will keep asking a user to
//               enter the next choice until the choice of 'Q' (Quit) is
//               entered. 

import java.io.*;
import java.io.Serializable;

public class Assignment8 implements Serializable
 {
  public static void main (String[] args)
   {
     char input1;
     String name, location, projNumStr, budgetStr;
     int projNumber;
     double budget;
     boolean operation = false;
     int operation2 = 0;
     String line;
     String filename;
     

     // create a ProjectManagement object. This is used throughout this class.
     ProjectManagement manage1 = new ProjectManagement();

     try
      {
       // print out the menu
       printMenu();

       // create a BufferedReader object to read input from a keyboard
       InputStreamReader isr = new InputStreamReader (System.in);
       BufferedReader stdin = new BufferedReader (isr);

       do
        {
         System.out.print("What action would you like to perform?\n");
         line = stdin.readLine().trim();  //read a line
         input1 = line.charAt(0);
         input1 = Character.toUpperCase(input1);

         if (line.length() == 1)          //check if a user entered only one character
          {
           switch (input1)
            {
             case 'A':   //Add Project
               try 
                {
                 System.out.print("Please enter a project name to add:\n");
                 name = stdin.readLine().trim();
                 System.out.print("Please enter its projNumber to add:\n");
                 projNumStr = stdin.readLine().trim();
                 projNumber = Integer.parseInt(projNumStr);
                 System.out.print("Please enter its location to add:\n");
                 location = stdin.readLine().trim();
                 System.out.print("Please enter its initial budget to add:\n");
                 budgetStr = stdin.readLine().trim();
                 budget = Double.parseDouble(budgetStr);

                 operation = manage1.addProject(name, location, projNumber, budget);
                 if (operation == true){
                  System.out.print("project added\n");
                 }else{
                  System.out.print("project exists\n");
                 }}
             catch( NumberFormatException ex  )
                {
                }
               break;
             case 'D':  //Search by projNumber
              try
               {
                 System.out.print("Please enter projNumber to search:\n");
                 projNumStr = stdin.readLine().trim();
                 projNumber = Integer.parseInt(projNumStr);
                 operation2=manage1.projNumberExists(projNumber);

                 if (operation2 > -1){
                   System.out.print("projNumber found\n");
                 }else{
                   System.out.print("projNumber not found\n");
                 }}
                catch( NumberFormatException ex  )
                {
                }
               break;
             case 'E':  //Search by name and location
                System.out.print("Please enter a name to search:\n");
                name = stdin.readLine().trim();
                System.out.print("Please enter a location to search:\n");
                location = stdin.readLine().trim();
                operation2=manage1.nameLocationExists(name, location);
                    
                if (operation2 > -1)
                    System.out.print("project name and location found\n");
                else
                    System.out.print("project name and location not found\n");
                break;
             case 'L':   //List projects
               System.out.print(manage1.listProjects());
               break;
             case 'O':  // Sort by projNumber
               manage1.sortByProjNumber();
               System.out.print("sorted by projNumber\n");
               break;
             case 'P':  // Sort by locations and project names
               manage1.sortByNameLocation();
               System.out.print("sorted by project names and locations\n");
               break;
             case 'Q':   //Quit
               break;
             case 'R':  //Remove by projNumber
              try
               {
                 System.out.print("Please enter projNumber to remove:\n");
                  projNumStr = stdin.readLine().trim();
                  projNumber = Integer.parseInt(projNumStr);
                  operation=manage1.removeProjNumber(projNumber);
                  if (operation == true)
                    System.out.print("projNumber removed\n");
                  else
                    System.out.print("projNumber not found\n");
                }

             catch( NumberFormatException ex  )
                {
                }
               break;
                case 'S':  //Remove by location and name
                    System.out.print("Please enter a name to remove:\n");
                    name = stdin.readLine().trim();
                    System.out.print("Please enter a location to remove:\n");
                    location = stdin.readLine().trim();
                    operation=manage1.removeNameLocation(name, location);
                    if (operation == true)
                        System.out.print("project name and location removed\n");
                    else
                        System.out.print("project name and location not found\n");
                    break;
             case 'T':  //Close ProjectManagement
               manage1.closeProjectManagement();
               System.out.print("project management system closed\n");
               break;
             case 'U':  //Write Text to a File
               System.out.print("Please enter a file name to write:\n");
               filename = stdin.readLine().trim();
               try{
            	FileWriter fw = new FileWriter(filename);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter pw = new PrintWriter(bw);             
              	System.out.print("Please enter a string to write in the file:\n");
            	String input = stdin.readLine().trim() + "\n";
            	
            	pw.print(input);
            	
            	System.out.print(filename + " was written\n");
            	
            	pw.close();
               }catch(IOException e){
            	   
               }

               
               
/************************************************************************************
***  ADD your code to write a text (string) to the specified file. Catch exceptions.
************************************************************************************/
               break;
             case 'V':  //Read Text from a File
               System.out.print("Please enter a file name to read:\n");
             
               filename = stdin.readLine().trim();
             
       	  try
          {
       		  
       		FileReader fr = new FileReader(filename);
    		System.out.print(filename +" was read\n");
    		try(BufferedReader inFile=new BufferedReader(fr)){//Found in Java API 
    		
          	String lineRead = inFile.readLine();//reads first line only
          	System.out.print("The first line of the file is:\n"+lineRead+"\n");
    		}catch(IOException ex){
          		
    		}
          }//end of try
          catch(FileNotFoundException ex)//type of exception is file not found
          { //ex is a variable
          		System.out.print(filename + " was not found\n");
          }
          catch(IOException ex)
          {
        	    System.out.print(filename + " was not found\n");
          }     
                
/************************************************************************************
***  ADD your code to read a text (string) from the specified file. Catch exceptions.
************************************************************************************/
               break;
             case 'W':  //Serialize ProjectManagement to a File
               System.out.println("Please enter a file name to write:");
               filename = stdin.readLine().trim();
               FileOutputStream fileOutput = null;
               ObjectOutputStream outStream = null;

               try
               {
                   
            	fileOutput = new FileOutputStream(filename);		  
                outStream  = new ObjectOutputStream(fileOutput);
                outStream.writeObject(manage1);
               	//instantiate and specify which file you're writing to. 
               	System.out.print(filename + " was written\n");
               	
               	outStream.close();
               }catch(NotSerializableException ex){
            	   System.out.print("Object Not Serializable\n");
               }catch(IOException ex){
            	   System.out.print("Invalid input. \n");
               }
/************************************************************************************
***  ADD your code to write the project management object to the specified file. Catch exceptions.
************************************************************************************/
               break;
              case 'X':  //Deserialize ProjectManagement from a File
               System.out.print("Please enter a file name to read:\n");
               filename = stdin.readLine().trim();
               FileInputStream fileInput;
               ObjectInputStream inStream;
               try{
            	   fileInput = new FileInputStream(filename);  
            	    inStream = new ObjectInputStream(fileInput);
            	    Object read = inStream.readObject(); //reads object
            	  if(read instanceof ProjectManagement){
            		  manage1 = (ProjectManagement)read;
            	   System.out.print(filename + " was read\n");
            	  }
            	   inStream.close();
            	   fileInput.close();
            	   
            	   
               }catch(ClassNotFoundException ex){
            	   System.out.print(filename + " was not found\n");
               }catch(IOException ex){
            	   System.out.print(filename + " was not found\n");
               }
/************************************************************************************
***  ADD your code to read a project management object from the specified file. Catch exceptions.
***********************************************************************************/
               break;
             case '?':   //Display Menu
               printMenu();
               break;
             default:
               System.out.print("Unknown action\n");
               break;
            }
         }
        else
         {
           System.out.print("Unknown action\n");
          }
        } while (input1 != 'Q' || line.length() != 1);
      }
     catch (IOException exception)
      {
        System.out.print("IO Exception\n");
      }
   }

  /** The method printMenu displays the menu to a user **/
  public static void printMenu()
   {
     System.out.print("Choice\t\tAction\n" +
                      "------\t\t------\n" +
                      "A\t\tAdd Project\n" +
                      "D\t\tSearch for ProjNumber\n" +
                      "E\t\tSearch for Name and Location\n" +
                      "L\t\tList Projects\n" +
                      "O\t\tSort by ProjNumber\n" +
                      "P\t\tSort by Name and Location\n" +
                      "Q\t\tQuit\n" +
                      "R\t\tRemove by ProjNumber\n" +
                      "S\t\tRemove by Name and Location\n" +
                      "T\t\tClose ProjectManagement\n" +
                      "U\t\tWrite Text to File\n" +
                      "V\t\tRead Text from File\n" +
                      "W\t\tSerialize ProjectManagement to File\n" +
                      "X\t\tDeserialize ProjectManagement from File\n" +
                      "?\t\tDisplay Help\n\n");
  }
} // end of Assignment8 class

