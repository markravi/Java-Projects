// Assignment #:8
//         Name:Markanday Ravi
//    StudentID:1209205799	
//      Lecture:T/Th 10:30
//  Description: The class creates the methods that will be used by the Assignment8 class. Uses all other classes.
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Vector;

public class ProjectManagement implements Serializable{
ArrayList projectList;
Project object;

	public ProjectManagement(){//Creates a new project Object
		projectList = new ArrayList();
	}
	public int projNumberExists(int projNumber){//Returns an item from the arraylist if the project number match
		//linear search
		int number, flag = -1;
		for(int i = 0; i < projectList.size();i++){
			number = ((Project) projectList.get(i)).getNumber();
			
			if(number == projNumber){
			flag = i;
				
			}
		}
		return flag;
	}
	public int nameLocationExists(String name, String location){//Returns an item from the arraylist if the name and location match.
		int flag = -1;
		String inputName, inputLoc;
		for(int i = 0; i < projectList.size();i++){
			inputName = ((Project) projectList.get(i)).getName();
			inputLoc = ((Project) projectList.get(i)).getLocation(); 
			
			if(inputName.compareTo(name) == 0){
				if(inputLoc.compareTo(location) == 0)
				
			flag = i;
			
			}
		}
		return flag;
	}
	//Takes in name, location, number, and budget to create a new item within the arraylist
	public boolean addProject(String name, String location, int projNumber, double initialFund){
		object = new Project(initialFund);
		object.setName(name);
		object.setLocation(location);
		object.setNumber(projNumber);
		int number;
		Boolean check = true;
		
		for(int i = 0; i < projectList.size();i++){
			
			number = ((Project) projectList.get(i)).getNumber();
			 if(number == projNumber){
			check = false;
			}
		}
		
		if(check == true){
			projectList.add(object);
		}
		
		
			
		return check;
	}
	public boolean removeProjNumber(int projNumber){//Removes an item from the arraylist according to project number
		int number;
	
		Boolean check = false;
		
		for(int i = 0; i < projectList.size();i++){
			
			number = ((Project) projectList.get(i)).getNumber();
			
			if(number == projNumber){
			projectList.remove(i);
			check = true;
			
			}
		}
		
		return check;
	}
	public boolean removeNameLocation(String name, String location){//Removes an item from the arraylist according to name and location.
		String inputName;
		String inputLoc;
		Boolean check = false;
		for(int i = 0; i < projectList.size();i++){
			inputName = ((Project) projectList.get(i)).getName();
			if(inputName.compareTo(name)==0){
			inputLoc = ((Project) projectList.get(i)).getLocation(); 
				if(inputLoc.compareTo(location)==0){
			projectList.remove(i);
				check = true;
			}
			}
		}
		return check;
	}
	public void sortByProjNumber(){//Sorts arraylist by project number
		ProjNumberComparator numComp = new ProjNumberComparator();

		Sorts.sort(projectList,numComp);
	}
	public void sortByNameLocation(){//Sorts arraylist by location and name, respectively
		ProjNameComparator nameComp = new ProjNameComparator();
		Sorts.sort(projectList,nameComp);
	}
	public String listProjects(){//Lists all the projects within the arraylist.
		String result = "\n";
		String place;
		if(projectList.size() == 0){//Returns if arraylist is empty
			 result = "\nno project\n";
		}else{
		for(int i =0;i<projectList.size();i++){
			place =projectList.get(i).toString();
			result+=place; 
		}
		
		}
		return result + "\n"; 
	}
	public void closeProjectManagement(){
		projectList.clear();//Clears the entire arraylist
	}

}
