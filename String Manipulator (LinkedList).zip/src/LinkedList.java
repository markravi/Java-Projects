// Assignment #: 10
//         Name: Markanday Ravi
//    StudentID: 1209205799
//  Lab Lecture: T/TH 10:30
//  Description: A linked list is a sequence of nodes with efficient
// 				 element insertion and removal. This class contains a 
//				 subset of the methods of the standard java.util.LinkedList 
//				 class.

import java.util.NoSuchElementException;

import org.w3c.dom.Node;

public class LinkedList
{
   //nested class to represent a node
   private class Node
   {
          public Object data;
          public Node next;
   }

   //only instance variable that points to the first node.
   private Node first;

   // Constructs an empty linked list.
   public LinkedList()
   {
      first = null;
   }


   // Returns the first element in the linked list.
   public Object getFirst()
   {
      if (first == null)
       {
         NoSuchElementException ex
             = new NoSuchElementException();
         throw ex;
       }
      else
         return first.data;
   }

   // Removes the first element in the linked list.
   public Object removeFirst()
   {
      if (first == null)
       {
         NoSuchElementException ex = new NoSuchElementException();
         throw ex;
       }
      else
       {
         Object element = first.data;
         first = first.next;  //change the reference since it's removed.
         return element;
       }
   }

   // Adds an element to the front of the linked list.
   public void addFirst(Object element)
   {
      //create a new node
      Node newNode = new Node();
      newNode.data = element;
      newNode.next = first;
      //change the first reference to the new node.
      first = newNode;
   }

   // Returns an iterator for iterating through this list.
   public ListIterator listIterator()
   {
      return new LinkedListIterator();
   }

   public String toString(){//Prints out all the nodes in order
	   Node pos = first;
	  
	   LinkedListIterator iter = new LinkedListIterator();
	   String str = "{ ";
	   while(iter.hasNext() == true){
		   str +=(String)(iter.next()) + " ";//adds each node 
	   }
	   str += "}\n";
	   return str;
   }
   public int size(){//Uses count variable to find size of linked list
	   LinkedListIterator iter = new LinkedListIterator();
	   int count = 0;
	   while(iter.hasNext() == true){
		   iter.next();
		   count++;
	   }
	  
	   return count;
   }
   public void addElementAt(Object element, int index){ //Adds an element at an index of the user's discretion
	   
	   int count = 1;
	   
	   if(index > size()){//If the index is greater than the size, it will return an exception
		   
		   IndexOutOfBoundsException ex = new IndexOutOfBoundsException();
		   throw ex;
	   }else{
		  
	   LinkedListIterator iter = new LinkedListIterator();
	   Node oldNode = first;
	   Node prevNode = null;
	   Node newNode = new Node();
	   newNode.data = element;
	   newNode.next= null;
	   while(count <= index){
		   prevNode = oldNode;//keeps track of node before the index of the node that will be inserted
	   oldNode = oldNode.next;
	   
	   count++;
	   }
	   if(index == 0){//If the linked list is empty
		   newNode.next = oldNode;
		   first = newNode;
			
	   }else{//inserts the node and reorganizes the .next locations of the other nodes
	   Node pointer = prevNode;
	   
	     newNode.next= oldNode;
	     pointer.next = newNode;
	   		}
	   }
   }
   public void addFewAtEnd(Object element, int howMany){//adds an element n times to the end of the array
	 
	   int repeat = howMany;
	   LinkedListIterator iter = new LinkedListIterator();
	  
	   while(iter.hasNext() == true){//iterates to the end of the loop
		   
		   iter.next();
		   
	   }
	   if(repeat > 0){
	while(repeat > 0){  
	   Node newNode = new Node();//creates new node, sets it equal to element, sets the .next location as null
	   newNode.data = element;
	   newNode.next= null;
	   if(first == null){//If the list is empty, it will automatically add to the beginning
		   first = newNode;
		   
	   }else{
		 iter.add(element);  //adds element at end
	   
	   
	   }
	   repeat--;//loops n times
	  }
	   }else{
		  
	  }
   }
   
   public void removeLastFew(int howMany){
	   if(howMany < 0){//skips if user inputs negative number
    	   
       }else{
	     do{
	        LinkedListIterator iter = new LinkedListIterator();
	        if(iter.hasNext() != true){//Checks to see if loop is empty, if so, then breaks
        		break;
	        }
	        int count = 0;
	        
	        	while(iter.hasNext() == true){//iterates to the end of the list
	        		 iter.next();
	        		count++;
	        		
		        	
	        	}
	        	
	        	if(howMany > count){//if the howMany is greater than count, it will remove all nodes till list is empty
	        		 LinkedListIterator iter1 = new LinkedListIterator();
	        		 iter1.next();
	        		while(iter1.hasNext()==true){
	        			iter1.remove();
	        			iter1.next();
	      
	        		}
	        		iter1.remove();
	        		
	        		break;
	        	}
	        		iter.remove();//remove node
	        		howMany--;
	        	}while(howMany != 0);//loops till the howMany is zero
   }
   }
	       	

	   
   public void removeAllOccurrences(Object stringToBeRemoved){
	   LinkedListIterator iter = new LinkedListIterator();
	   Node node = first;
	   while(iter.hasNext() == true){//iterates to the first node
		  
		   iter.next();
		  
   		if(stringToBeRemoved.equals(node.data)){//if the stringToBeRemoved equals any of the nodes' data, then it will remove it
		   iter.remove();
	   }
   		if(iter.hasNext() == true){//if there is another node after, it will iterate to it.
   			node = node.next;
   		}
   		
	   }
	   }
   
   
   public void reverseLastFew(int howMany){
	  if(howMany >= 0){
	   
		  if(howMany > size()){//if user's input is greater than size, sets input equal to size.
		   howMany = size();
	   }
	   
	   LinkedListIterator iterStart = new LinkedListIterator();
	   LinkedListIterator iterEnd = new LinkedListIterator();
	   int size = size();
	   int sizeBetween;
	   int replace = size()-howMany + 1;//counts up to where the first node should be switched
	   
	  do{
	   int sizeCount = 0;
	   int countEnd = 0;
	   Node lastNode = first;
	   Node firstNode = first;
	   Object placeHolder = null;
	   
	   	while(size > 0){//iterates to the right most node that needs to be switched
		   iterEnd.next();
		   	
		   if(size > 1){
		   lastNode = lastNode.next;
		   }
		   
		   sizeCount++;
		   size--;
	   }
	   
	   	while(replace > 0){//iterates to the left most node that needs to be switched
		   iterStart.next();
		   
		   if(replace > 1){
		   firstNode = firstNode.next;//pointing at first node to be switched
		   }
		   
		   countEnd++;
		   replace--;
	   }
	  
	   placeHolder = firstNode.data;
	   iterStart.set(lastNode.data);//switches first with last
	   iterEnd.set(placeHolder);//switches last with first
	   
	   
	   //restarts iterators
	   iterEnd = new LinkedListIterator();
	   iterStart = new LinkedListIterator();
	   size = sizeCount-1; 
	   replace = countEnd + 1;//moves replace so firstNode becomes the next left most node that needs to be switched
	   sizeBetween = size-countEnd; //counts the size between the nodes that need to be reversed
	   }while (sizeBetween > 1);//continues to loop as long as the sizeBetween is greater than 1
   }
   }

   //nested class to define its iterator
   private class LinkedListIterator implements ListIterator
   {
      private Node position; //current position
      private Node previous; //it is used for remove() method

      // Constructs an iterator that points to the front
      // of the linked list.

      public LinkedListIterator()
      {
         position = null;
         previous = null;
      }

     // Tests if there is an element after the iterator position.
     public boolean hasNext()
      {
         if (position == null) //not traversed yet
          {
             if (first != null)
                return true;
             else
                return false;
          }
         else
           {
              if (position.next != null)
                 return true;
              else
                 return false;
           }
      }

      // Moves the iterator past the next element, and returns
      // the traversed element's data.
      public Object next()
      {
         if (!hasNext())
          {
           NoSuchElementException ex = new NoSuchElementException();
           throw ex;
          }
         else
          {
            previous = position; // Remember for remove

            if (position == null)
               position = first;
            else
               position = position.next;

            return position.data;
          }
      }

      // Adds an element before the iterator position
      // and moves the iterator past the inserted element.
      public void add(Object element)
      {
         if (position == null) //never traversed yet
         {
            addFirst(element);
            position = first;
         }
         else
         {
            //making a new node to add
            Node newNode = new Node();
            newNode.data = element;
            newNode.next = position.next;
            //change the link to insert the new node
            position.next = newNode;
            //move the position forward to the new node
            position = newNode;
         }
         //this means that we cannot call remove() right after add()
         previous = position;
      }

      // Removes the last traversed element. This method may
      // only be called after a call to the next() method.
      public void remove()
      {
         if (previous == position)  //not after next() is called
          {
            IllegalStateException ex = new IllegalStateException();
            throw ex;
          }
         else
          {
           if (position == first)
            {
              removeFirst();
            }
           else
            {
              previous.next = position.next; //removing
            }
           //stepping back
           //this also means that remove() cannot be called twice in a row.
           position = previous;
      }
      }

      // Sets the last traversed element to a different value.
      public void set(Object element)
      {
         if (position == null)
          {
            NoSuchElementException ex = new NoSuchElementException();
            throw ex;
          }
         else
          position.data = element;
      }
   } //end of LinkedListIterator class
} //end of LinkedList class