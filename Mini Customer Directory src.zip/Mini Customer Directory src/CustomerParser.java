// Assignment #: 5
// Arizona State University - CSE205
//         Name: Markanday Ravi	
//    StudentID: 1209205799
//      Lecture: T/TH 10:30 
//  Description: The CustomerParser class separates the input by '/', and parses through to determine whether the input was
//  from a Member Customer or NonMember Customer.

import java.util.Scanner;

public class CustomerParser {
	public static Customer parseStringToCustomer(String lineToParse){
	Scanner in = new Scanner(lineToParse).useDelimiter("/"); //Sets the item to break the input apart as '/'
	String something = "M";
if(in.next() == something){
	String[] Array = new String[7];
	for(int i =0; i < 7; i++){ //This loop finds and returns each complete input between the '/' if the input is for a MemberCustomer.
		Array[i] = in.next();
	}
	Customer returningCustomer = new MemberCustomer(Array[0],Array[1],Double.parseDouble(Array[2]),Integer.parseInt(Array[3]),
			Integer.parseInt(Array[4]),Integer.parseInt(Array[5]),Integer.parseInt(Array[6])); //Will assign each input from the user to a variable in the MemberCustomer class
	return returningCustomer;
}else{//This loop finds and returns each complete input between the '/' if the input is for a NonMemberCustomer.
	String[] Array = new String[7];
	for(int i =0; i < 7; i++){
		Array[i] = in.next();
	}
	Customer nonCustomer = new NonMemberCustomer(Array[0],Array[1],Double.parseDouble(Array[2]),Integer.parseInt(Array[3]),
			Integer.parseInt(Array[4]),Integer.parseInt(Array[5]),Double.parseDouble(Array[6])); //Will assign each input from the user to a variable in the NonMemberCustomer class
	return nonCustomer;
}
}
}