import java.text.NumberFormat;

// Assignment #: 5
// Arizona State University - CSE205
//         Name: Markanday Ravi	
//    StudentID: 1209205799
//      Lecture: T/TH 10:30 
//  Description: The Customer class is the parent class to MemberCustomer and NonMemberCustomer. It returns the purchased amount and instantiates all the variables
//  to the parameters within its method.
public abstract class Customer {
	protected String firstName, lastName;
	protected double purchasedAmount, paymentAmount;
	protected int purchasedYear, purchasedMonth, purchasedDate;
	//Declares all the basic variables to be used
	public Customer(String fName, String lName, double amount, int year, int month, int date){
		firstName = fName;
		lastName = lName;
		purchasedYear = year;
		purchasedMonth = month;
		purchasedDate = date;
		purchasedAmount = amount;
		paymentAmount = 0.0;
		//Sets the variables to each parameter within the Customer method
	}
	public double getPurchasedAmount(){
		return purchasedAmount;
	}
	public abstract void computePaymentAmount();
	
	public String toString(){ //Output for Customer
		NumberFormat money = NumberFormat.getCurrencyInstance();
		String output = "\nFirst name:\t\t" + firstName + "\nLast name:\t\t" + lastName + "\nPurchased Amount:\t" + money.format(purchasedAmount) + 
				"\nPurchased Date:\t\t" + purchasedMonth + "/" + purchasedDate + "/" + purchasedYear + "\nPayment Amount:\t\t" + money.format(paymentAmount) + "\n";

		return output;
	}



}

