// Assignment #: 5
// Arizona State University - CSE205
//         Name: Markanday Ravi	
//    StudentID: 1209205799
//      Lecture: T/TH 10:30 
//  Description: The NonMemberCustomer class is a child of the Customer class. It calculates the payment amount for a nonmember customer
//  as well as their visitfee. The output is customized for a nonmember customer only.

import java.text.NumberFormat;

public class NonMemberCustomer extends Customer{

private double visitFee;
public NonMemberCustomer(String fName, String lName, double amount, int year, int month, int date, double fee){
	super(fName, lName, amount, year, month, date);
	visitFee = fee;
	
	//Sets the variables to each parameter within the NonMemberCustomer method
}
public void computePaymentAmount(){
	paymentAmount = purchasedAmount + visitFee;
	//Adds a $10 visit fee to the payment amount for the NonMember customer 
}
public String toString(){
	NumberFormat money = NumberFormat.getCurrencyInstance();
	String output = "\nNonMember Customer:" + super.toString() + "Visit Fee:\t\t" + money.format(visitFee) + "\n\n";
	return output;
//Updated output for NonMemberCustomer
}


}
