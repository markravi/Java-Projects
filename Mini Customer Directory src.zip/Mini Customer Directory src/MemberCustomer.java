// Assignment #: 5
// Arizona State University - CSE205
//         Name: Markanday Ravi	
//    StudentID: 1209205799
//      Lecture: T/TH 10:30 
//  Description: The MemberCustomer class is a child of the Customer class. It calculates the payment amount for a member customer
//  as well as the points collected by that member. The output is customized for a member customer only.
public class MemberCustomer extends Customer{
	
	private int pointsCollected;
public MemberCustomer(String fName, String lName, double amount, int year, int month, int date, int points){
	
	super(fName, lName, amount, year, month, date);
	pointsCollected = points;
	
	//Sets the variables to each parameter within the MemberCustomer method
}
//customer m = new membercustomer(arry[0], array[1]
public void computePaymentAmount(){
	
	if(pointsCollected > 100){
		paymentAmount = purchasedAmount * (0.8);
		//If the points collected by the member is greater than 100, it will discount the payment by 20%
	}else{
		paymentAmount = purchasedAmount * (0.9);
	}//If not, then the user will get a discount of 10%
	int pAmount = (int) (purchasedAmount * 0.01);
	pointsCollected =  pointsCollected + pAmount;
	//Updates the points collected by the member
}
public String toString(){
	String output = "\nMember Customer:" + super.toString() + "Collected Points:\t" + pointsCollected + "\n\n";
	return output;
	//Updated output for a Member Customer.
}
}
