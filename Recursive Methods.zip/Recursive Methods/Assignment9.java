// Assignment #: 9
//         Name:Markanday Ravi
//    StudentID:1209205799
//      Lecture:T/TH 10:30
//  Description: The Assignment 9 class uses recursion to calculate the minimum number inputed,
//               the count of even numbers, count of numbers greater than the first input, and
//               the sum of the negative numbers inputed.
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Assignment9 {
	
	public static void main (String[] args)
	   {
		try{
			String line;
			int[] numberArray = new int[100];
			int min = 0, even = 0, negative = 0, greater = 0;
			int input = -1;
			int count = 0;
			InputStreamReader isr = new InputStreamReader (System.in);
		    BufferedReader stdin = new BufferedReader (isr);
			//Initializes all variables, allows for user input using Reader packages.
				
			for(int i =0;i <= 100;i++){
				line = stdin.readLine().trim();  //read a line
		        input = Integer.parseInt(line);//Parses for int
				numberArray[i] = input;
				count++;//counts number of actual user inputs in array
				min = findMin(numberArray, 0, count-1);
				even = countEven(numberArray,0,count-1);
				negative = computeSumOfNegative(numberArray,0,count-1);
				greater = countGreaterThanFirst(numberArray,0,count-1,numberArray[0]);
				//Use methods to calculate min, counts of even/greater, negative sum
				if(input == 0){ //Breaks loop when 0 is inputed 
					break;
				}
			}
			
			System.out.println("The minimum number is " + min);
			System.out.println("The total count of even numbers is " + even);
			System.out.println("The sum of negative numbers is " + negative);
			System.out.println("The total count of numbers that are greater than the first is " + greater);
			 //Outputs
	    
		}catch(NullPointerException ex){
			System.out.println("There is error");
		}
		catch(IOException ex){
			System.out.println("There is error");
		}
	   }
	//Finds the minimum using recursion
	public static int findMin(int[] numbers, int startIndex, int endIndex){ 
		
		 if(startIndex == endIndex){//Base Case
			 return numbers[startIndex];
		 }else{
		 int oldMin = findMin(numbers, startIndex, endIndex-1);
		 if(oldMin < numbers[endIndex]){//checks to see if the newest input is greater than the current minimum
			 return oldMin;
		 }
			 else{
				 return numbers[endIndex];
		 }
		 		 
		 
		 }
}	//Finds even using recursion
    public static int countEven(int[] numbers, int startIndex, int endIndex){
   
    	if(startIndex == endIndex){//Base Case
    		if(numbers[startIndex]%2 == 0){//If the first input is even, returns 1, if not, returns 0
    		return 1;
    		}
    		return 0;
    		
    	}else{
    		
    	if(numbers[endIndex]%2 == 0){//Checks if the newest input in even, adds to current count of even inputs
    		
    		return 1 + countEven(numbers, startIndex, endIndex-1);
    	}else{
    		return countEven(numbers, startIndex, endIndex-1);	
    	}
    	}
    	
    }
    
    //Calculates the sum of Negative inputs
    public static int computeSumOfNegative(int[] numbers, int startIndex, int endIndex){
    	int negative = 0;
    	if(startIndex == endIndex){//Base Case
    	if(numbers[startIndex] < 0){
    		return negative = numbers[startIndex];
    	}
    	return negative;
    	}else{
    		negative = computeSumOfNegative(numbers, startIndex, endIndex-1);
    		if(numbers[endIndex] < 0){//Adds to the current sum of negative numbers
    			return negative + numbers[endIndex];
    		}else{
    			return negative;
    		}
    	}
    }
    //Calculates sum of inputs greater than the first
    public static int countGreaterThanFirst(int[] numbers, int startIndex, int endIndex, int firstNumber){
    	int count;
    	if(startIndex == endIndex){//Base Case
			 
    		return count = 0;
			 
		 }else{
		 count = countGreaterThanFirst(numbers, startIndex, endIndex-1, firstNumber);
		 
		 if(numbers[endIndex] > firstNumber){//Checks to see if newest input is greater than first, returns current count.
			 count++;
			 return count;
		 }
			 else{
				 return count;
		 }
		 		 
		 
		 }
    }
}

