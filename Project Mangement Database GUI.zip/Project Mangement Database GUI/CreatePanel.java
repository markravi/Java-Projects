// Assignment #: 6
//         Name: Markanday Ravi
//    StudentID: 1209205799
//      Lecture: T/TH 10:30
//  Description: This class sets up the first tab, and takes in user input and outputs it onto a textview. It will also
//					

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.util.*;

public class CreatePanel extends JPanel
 {
   private Vector projectList;
   private JButton createProj;
   private ProjectSpendingPanel spendingPanel;
   ButtonListener listen;
   JLabel projName;
   JTextField inputName;
   JLabel projNumber;
   JTextField inputNumber;
   JScrollPane scroll;
   JLabel projLoc;
   JTextField inputLoc;
   JLabel initialFunding;
   JTextField inputFunding;
   JTextArea projectOutput;
   String name, number, funding, location;
   JPanel leftSide;
   JPanel top;
   JPanel center;
   JPanel first;
   JPanel second;
   JPanel bottom;
   JLabel result;
   int num; 
   double funds;
   Project proj;
 //Constructor initializes components and organize them using certain layouts
 public CreatePanel(Vector projectList, ProjectSpendingPanel spendingPanel)
  {
    setLayout(new GridLayout(1,2));
    
    createProj = new JButton("Create a project");
    listen = new ButtonListener();
    createProj.addActionListener(listen);
    
    initialFunding = new JLabel("Initial Funding:");
    inputFunding = new JTextField();
    
   
    
    projName = new JLabel("Project Name:");
    inputName = new JTextField();
    
    
    projNumber = new JLabel("Project Number:");
    inputNumber = new JTextField();
    
    projectOutput = new JTextArea("No Project");
    projectOutput.setSize(50,800);
    
    scroll = new JScrollPane(projectOutput);
    
    projLoc = new JLabel("Project Location:");
    inputLoc = new JTextField();
    //Initializes all the components.
    
    leftSide = new JPanel();
    add(leftSide);
    leftSide.setLayout(new GridLayout(3,1));
    
    top = new JPanel();
    top.setLayout(new BorderLayout());
    result = new JLabel();
	result.setForeground(Color.RED);
	top.add(result, BorderLayout.WEST);  
    leftSide.add(top);
    
    center = new JPanel();
    center.setLayout(new GridLayout(1,2));
    
    first = new JPanel();
    first.setLayout(new BoxLayout(first,BoxLayout.Y_AXIS));
    first.add(projName);
    first.add(Box.createVerticalGlue()); 
    first.add(projNumber);
    first.add(Box.createVerticalGlue()); 
    first.add(projLoc);
    first.add(Box.createVerticalGlue()); 
    first.add(initialFunding);
    first.add(Box.createVerticalGlue()); 
    
   
    second = new JPanel();
    second.setLayout(new BoxLayout(second, BoxLayout.Y_AXIS));
    second.add(inputName);
    second.add(inputNumber);
    second.add(inputLoc);
    second.add(inputFunding);
    
    center.add(first);
    center.add(second);
    leftSide.add(center);
    
    bottom = new JPanel();
    bottom.setLayout(new FlowLayout());
    bottom.add(createProj);

    leftSide.add(bottom);
    add(scroll);
    
    this.projectList = projectList;
    this.spendingPanel = spendingPanel;
    //organize components here
  }


  //ButtonListener is a listener class that listens to
  //see if the buttont "Create a project" is pushed.
  //When the event occurs, it adds a project information from
  //the text fields to the text area. It also creates a Project object
  //using theinformation and add it to the projectList.
  //It also does error checking.
  private class ButtonListener implements ActionListener
   {
    public void actionPerformed(ActionEvent event)
     {
    	 if(inputName.getText().isEmpty() || inputFunding.getText().isEmpty() 
    			 || inputLoc.getText().isEmpty() || inputNumber.getText().isEmpty() || inputFunding.getText().isEmpty()){
    		 result.setText("Please fill in all fields");
         }
         
    //Checks if any of the fields are empty
    	 else{
        	 try{
    	   funding = inputFunding.getText();
           funds = Double.parseDouble(funding);
           proj = new Project(funds);
           name = inputName.getText();
           proj.setName(name);
           //Gets the user's text and sets it to the project name
           number = inputNumber.getText();
           num = Integer.parseInt(number);
           proj.setNumber(num);
         //Gets the user's text and sets it to the project number
           location = inputLoc.getText();
           proj.setLocation(location);
         //Gets the user's text and sets it to the project location
           result.setText("Project added");
    	   inputFunding.setText("");
    	   inputName.setText("");
    	   inputNumber.setText("");
    	   inputLoc.setText("");
    	   //Empty's the text fields
    	   proj.toString();
           String str = projectOutput.getText();
           projectOutput.setText(str + proj.toString());
           projectList.add(proj);
           spendingPanel.updateProjectList(); //updates the projectList
           
       }catch(NumberFormatException ex){
    	   result.setText("Please enter a numeric value for project name and spending.");
    	   result.setForeground(Color.RED);//catches the string input in a text that should take in only a int or double input
       }
        
           
       }
     
       
    	// if there is no error, add a project to project list
       // otherwise, show an error message

     } //end of actionPerformed method
  } //end of ButtonListener class

} //end of CreatePanel class