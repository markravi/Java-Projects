// Assignment #: 6
//         Name: Markanday ravi
//    StudentID: 1209205799
//      Lecture: T/TH 10:30
//  Description: This class sets up the second tab. It shows a list of lists added by the Create Panel class
//               and also has a button that will allow the user to add spending. Then it will update the list.

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

public class ProjectSpendingPanel extends JPanel
 {
     private Vector projectList;
     
     JList list;
     JTextField spendingField;
     private JButton addSpending;
     JLabel chooseProject;
     JLabel specifyAmount; 
     JTextArea containList;
     ButtonListener listen;
     JPanel projLabel;
     String spending;
     double userSpending;
     Project proj;
    // JList, labels, and a button
   
     
    //Constructor initialize each component and arrange them using
   //certain layouts
   public ProjectSpendingPanel(Vector projectList)
     {
	   	 setLayout(new BorderLayout());
         this.projectList = projectList;
         list = new JList(projectList); //Initializes the list to output the projectList Vector
         list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //User can choose only one list
          spendingField = new JTextField(70);
         
          addSpending = new JButton("Add Spending");
           listen = new ButtonListener();
           addSpending.addActionListener(listen);
           //Initializes the button
         chooseProject = new JLabel("Choose a project to specify some spending:");
          specifyAmount = new JLabel ("Specify your amount to spend");  
          //Initializes all the J's
         add(chooseProject,BorderLayout.NORTH);
         add(list,BorderLayout.CENTER);
         projLabel = new JPanel();
         projLabel.setLayout(new BorderLayout());
         projLabel.add(specifyAmount, BorderLayout.NORTH);
         projLabel.add(spendingField, BorderLayout.WEST);
         projLabel.add(addSpending,BorderLayout.EAST);
         add(projLabel,BorderLayout.SOUTH);
         //Sets up the layout and adds in all the component
         
         
         //organize components for spending panel
         
         
     }
   

 //This method  refreshes the JList with
 //updated vector information
 public void updateProjectList()
  {
     list.updateUI(); //call updateUI() for the JList object
      
     }
	 
  





 //ButtonListener class listens to see the button "Add Spending" is pushed.
 //A user can choose which project to add spending, and that will update the
 //spending and current balance of such project.
  private class ButtonListener implements ActionListener
  {
      
	public void actionPerformed(ActionEvent event)
        {
		 
          spending = spendingField.getText();
          userSpending = Double.parseDouble(spending); //Converts string to double
          int index = list.getSelectedIndex();
          proj = (Project)projectList.get(index); //gets the index of the list the user choose
          if(proj.addExpenditure(userSpending)){
        	  updateProjectList();//Updates the project list every time the button.
        	  
          }
    //get some additional spending from the textfield, update the spending and current balance for the chosen project in the JList.
        }
  } //end of ButtonListener class

} //end of ProjectSpendingPanel class